from flask import Flask, url_for, request, redirect

app = Flask(__name__)
a = False


@app.route('/')
@app.route('/index')
def index():
    return "Привет, Яндекс!"


@app.route('/form_sample', methods=['POST', 'GET'])
def form_sample():
    global a
    if request.method == 'GET':
        if a:
            img = f"<img src={url_for('static', filename='img/img.jpg')}> <br/>"
        else:
            img = ''
        return f'''<!doctype html>
                        <html lang="en">
                          <head>
                            <meta charset="utf-8">
                            <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
                            <link rel="stylesheet"
                            href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css"
                            integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1"
                            crossorigin="anonymous">
                            <link rel="stylesheet" type="text/css" href="{url_for('static', filename='css/style.css')}"/>
                            <title>Пример формы</title>
                          </head>
                          <body>
                            <h1>Можно грузануть картинку.</h1>
                            <h2>Прямо в форму снизу.</h2>
                            <div>
                                <form class="login_form" method="post" enctype="multipart/form-data">
                                    <div class="form-group">
                                        <label class="aboba" for="photo">Приложите фотографию</label>
                                        <input type="file" class="form-control-file" id="photo" name="file">
                                    </div>
                                    {img}
                                    <button type="submit" class="btn btn-primary">Грузануть фотку</button>
                                </form>
                            </div>
                          </body>
                        </html>'''
    elif request.method == 'POST':
        f = request.files['file']
        with open('static/img/img.jpg', 'wb') as fil:
            fil.write(f.read())
        a = True
        return redirect('http://127.0.0.1:8080/form_sample')


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')
